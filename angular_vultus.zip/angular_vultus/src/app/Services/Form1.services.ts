import { Injectable } from '@angular/core';
import { User } from '../models/User';

@Injectable(
    {
        providedIn: 'root'
    }
)
export class Form1Services {

   
    public Form1: User[] = [
        {ID:1, Name: 'Michael', Age: 20, Gender: 1, Email: 'a@gmail.com', Password: 'aaa', Status: 'U',Address: 'New Jersey'  },
        {ID:1, Name: 'sam', Age: 40, Gender: 1, Email: 's@g.com', Password: 'asd', Status: 'U',Address: 'Edison' },
        {ID:1, Name: 'monica', Age: 30, Gender: 2, Email: 'd@g.com', Password: 'dshg', Status: 'Es',Address: 'Somerset' }

    ]
    constructor() { }

    public getForm1(): User[] {
        return this.Form1;

    }

    public saveUser(user: User) {
        this.Form1.push(user);
    }

    public deleteUser(name: string) {
        debugger;
        const idx = this.Form1.findIndex(i => i.Name === name);
        this.Form1.splice(idx, 1);

    }


}