export interface User {
    ID:number;
    Name: string;
    Gender: number;
    Age: number;
    Status: string;
    Email: string;
    Password: string;
    Address:String;
    
  }
  