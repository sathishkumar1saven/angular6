import { Component } from '@angular/core';
import { User } from './models/User'
import { Form1Services } from './Services/Form1.services';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  public userList: User[];
  public User: User = {
    ID: 0,
    Name: '',
    Gender: 0,
    Age: 0,
    Status: '',
    Email: '',
    Password: '',
    Address: '',

  };
  constructor(private svcForm1: Form1Services) { }

  public ngOnInit() {
   this.bindUserList();
  }

  public ClickMe() {
    this.svcForm1.saveUser(this.User);
    this.bindUserList();
    alert('Successfully Saved');
  }
  public bindUserList() {
     this.userList = this.svcForm1.getForm1();
  }
  public deleteUser(name: string) {
    this.svcForm1.deleteUser(name);
    this.bindUserList();
    alert('Deleted Successfully.')
  }
  public submit(){
    alert(`successfully login`);
  }

}

