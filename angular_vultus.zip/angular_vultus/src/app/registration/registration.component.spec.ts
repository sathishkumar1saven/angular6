import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { REGISTRATIONComponent } from './registration.component';

describe('REGISTRATIONComponent', () => {
  let component: REGISTRATIONComponent;
  let fixture: ComponentFixture<REGISTRATIONComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ REGISTRATIONComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(REGISTRATIONComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
