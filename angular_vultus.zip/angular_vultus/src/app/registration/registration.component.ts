import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class REGISTRATIONComponent implements OnInit {

  user:string;
  password:string;

  constructor() { }

  ngOnInit() {
  }

}
