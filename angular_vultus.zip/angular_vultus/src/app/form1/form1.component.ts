import { Component, OnInit, OnDestroy, OnChanges } from '@angular/core';
import { User } from '../models/User';


@Component({
  selector: 'app-form1',
  templateUrl: './form1.component.html',
  styleUrls: ['./form1.component.css']
})

export class Form1Component  {
 
  public Usr: User = {
    ID: 0,
    Name: '',
    Age:0,
    Gender:0,
    Status:'',
    Email:'',
    Password:'',
    Address:''
  }
  constructor() {

  }

}
